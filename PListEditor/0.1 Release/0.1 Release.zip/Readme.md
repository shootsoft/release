# PList Editor

An editor for property list file (.plist)

# Release

## 0.1
- Open, edit and save binary or xml plist files
- System file association
- Xml formatter
- Xml highlight
